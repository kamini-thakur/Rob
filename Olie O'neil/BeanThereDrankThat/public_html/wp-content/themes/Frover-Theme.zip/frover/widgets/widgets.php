<?php
get_template_part('widgets/flickr-widget');
get_template_part('widgets/latest-blog-posts');
get_template_part('widgets/latest-portfolio-posts');
get_template_part('widgets/footer-highlight');
get_template_part('widgets/social-widget');
get_template_part('widgets/two-column-home');
?>